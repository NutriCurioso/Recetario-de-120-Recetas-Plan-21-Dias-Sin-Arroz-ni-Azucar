//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-Cbap7_FB.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/"],
		preloads: ["/assets/index-BOI0e-NN.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-BOI0e-NN.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-C98dbWAW.js"]
	}
} });
//#endregion
export { tsrStartManifest };
