import { i as __toESM } from "../_runtime.mjs";
import { K as require_react, b as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as Lock, c as ChevronDown, i as ShieldCheck, l as Check, o as Leaf, r as Sparkles, s as Clock, t as UtensilsCrossed } from "../_libs/lucide-react.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-Dfh30Ukh.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var CHECKOUT = "https://pay.hotmart.com/P87324279V?checkoutMode=10&ref=P107932025G";
var INCLUDES = [
	{
		title: "120 recetas para desinflamar",
		detail: "Desayunos, almuerzos, cenas y snacks de 5 a 20 minutos. Ingredientes de mercado, no de dietética cara."
	},
	{
		title: "Plan de 21 días sin arroz ni azúcar",
		detail: "Qué comer cada día, ya armado. Dejas de improvisar a las 8 de la noche."
	},
	{
		title: "Guía de ejercicios en casa",
		detail: "15 a 20 minutos. Sin gym, sin máquinas, sin experiencia previa."
	},
	{
		title: "Plan de hábitos diarios",
		detail: "Agua, sueño, antojos y constancia. El sistema que sostiene el resultado."
	},
	{
		title: "Grupo de WhatsApp",
		detail: "Recetas nuevas cada semana y mujeres haciendo el mismo proceso que tú."
	}
];
var BONUSES = [
	{
		name: "Grupo VIP de WhatsApp",
		value: "$47"
	},
	{
		name: "Recetario de jugos verdes",
		value: "$37"
	},
	{
		name: "Plan de hábitos de 21 días",
		value: "$27"
	},
	{
		name: "Lista de compras para imprimir",
		value: "$17"
	},
	{
		name: "Guía de ejercicios 15–20 min",
		value: "$27"
	}
];
var QUOTES = [
	{
		name: "Liliany",
		result: "−4 kg",
		text: "El reto me dio mucha motivación. Logré perder 4 kg y voy por más. Los recomiendo al 100."
	},
	{
		name: "Meri",
		result: "Sigue bajando",
		text: "Me encantó. Bajé muchísimo y lo recomiendo. Sigo bajando."
	},
	{
		name: "Jean",
		result: "Mucha disciplina",
		text: "Excelente. Rebajé muchísimo con este reto. Con disciplina todo se puede."
	},
	{
		name: "Glenny",
		result: "Lo repetiría",
		text: "Me fue muy bien. Buen resultado y lo volvería a tomar de nuevo."
	},
	{
		name: "Janni",
		result: "Jugos verdes",
		text: "Me gustaron las comidas por día. Los jugos verdes me ayudaron a rebajar mucho."
	},
	{
		name: "Evelyn",
		result: "−4 kg",
		text: "Este es mi peso de hoy. En total he perdido 4 kg. Súper feliz con el plan."
	}
];
var FAQS = [
	{
		q: "¿Cómo lo recibo?",
		a: "Pago único en Hotmart. En menos de un minuto te llega el acceso a tu correo. No hay envío físico."
	},
	{
		q: "¿Sirve si trabajo todo el día?",
		a: "Sí. Las recetas son de 5 a 20 minutos y el plan ya dice qué comer. No tienes que inventar menús."
	},
	{
		q: "¿Necesito gym o experiencia?",
		a: "No. Los ejercicios son en casa, 15 a 20 minutos, sin equipo."
	},
	{
		q: "¿Qué pasa si no me gusta?",
		a: "Tienes 7 días. Si no es para ti, escribes y te devuelven el 100%. Sin preguntas."
	},
	{
		q: "¿Puedo usarlo si estoy lactando o tengo una condición?",
		a: "Es un plan de alimentación, no un tratamiento médico. Si estás embarazada, lactando o con una condición diagnosticada, consúltalo con tu médico antes."
	}
];
function parts(diff) {
	const h = Math.floor(diff / 36e5);
	const m = Math.floor(diff % 36e5 / 6e4);
	const s = Math.floor(diff % 6e4 / 1e3);
	return {
		h: String(h).padStart(2, "0"),
		m: String(m).padStart(2, "0"),
		s: String(s).padStart(2, "0")
	};
}
function msUntilMidnight() {
	const now = /* @__PURE__ */ new Date();
	const end = new Date(now);
	end.setHours(23, 59, 59, 0);
	let diff = end.getTime() - now.getTime();
	if (diff < 1500) {
		end.setDate(end.getDate() + 1);
		diff = end.getTime() - now.getTime();
	}
	return diff;
}
function useDeadline() {
	const [left, setLeft] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => {
		const tick = () => setLeft(parts(msUntilMidnight()));
		tick();
		const id = setInterval(tick, 1e3);
		return () => clearInterval(id);
	}, []);
	return left;
}
function Cta({ children, subtle = false }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
		href: CHECKOUT,
		className: subtle ? "inline-flex min-h-12 items-center justify-center rounded-full border border-forest/20 bg-surface px-6 text-base font-semibold text-forest transition hover:bg-bg-deep" : "inline-flex min-h-14 w-full items-center justify-center rounded-full bg-clay px-6 text-lg font-semibold text-surface shadow-[0_10px_30px_-12px_rgba(196,92,38,0.8)] transition hover:bg-clay-deep sm:w-auto",
		children
	});
}
function Home() {
	const t = useDeadline();
	const [open, setOpen] = (0, import_react.useState)(0);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "pb-28 sm:pb-0",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "bg-forest text-surface",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto flex max-w-5xl flex-wrap items-center justify-center gap-x-4 gap-y-1 px-4 py-2 text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "font-medium",
						children: "Precio de hoy: $9.99 en vez de $47"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "tabular-nums text-gold",
						children: t ? `cierra en ${t.h}:${t.m}:${t.s}` : "solo por hoy"
					})]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "mx-auto flex max-w-5xl items-center justify-between px-5 py-5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-display text-xl text-forest",
					children: "Plan 21 Días"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
					href: CHECKOUT,
					className: "hidden min-h-11 items-center rounded-full bg-forest px-5 text-sm font-semibold text-surface sm:inline-flex",
					children: "Empezar hoy"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "mx-auto grid max-w-5xl items-center gap-10 px-5 pb-16 pt-4 lg:grid-cols-[1.05fr_0.95fr]",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mb-4 inline-flex items-center gap-2 rounded-full bg-bg-deep px-3 py-1 text-sm font-medium text-forest",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Leaf, { className: "size-4" }), " Para mujeres de 24 a 55 años"]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
							className: "font-display text-4xl leading-[1.05] tracking-tight text-ink sm:text-6xl",
							children: "Come rico. Desinflama. Baja de peso en 21 días."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-5 max-w-xl text-lg text-muted",
							children: "120 recetas + un plan día por día, sin arroz y sin azúcar. Hecho para quien ya está cansada de empezar el lunes y abandonar el miércoles."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-6 flex flex-wrap gap-3 text-sm",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "rounded-full bg-surface px-3 py-2 ring-1 ring-line",
									children: "+2.300 mujeres"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "rounded-full bg-surface px-3 py-2 ring-1 ring-line",
									children: "Promedio reportado −5.4 kg"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "rounded-full bg-surface px-3 py-2 ring-1 ring-line",
									children: "5–20 min por receta"
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-8 flex flex-col gap-3 sm:flex-row sm:items-center",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Cta, { children: "Quiero mi recetario · $9.99" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-sm text-muted",
								children: "Pago único · Acceso de por vida · Garantía 7 días"
							})]
						})
					] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "relative",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
							src: "/food/bowl.jpg",
							alt: "Bowl de yogur con frutas y menta",
							className: "aspect-[4/3] w-full rounded-3xl object-cover shadow-xl"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "absolute -bottom-5 left-4 right-4 rounded-2xl bg-surface p-4 shadow-lg ring-1 ring-line sm:left-auto sm:right-6 sm:w-64",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xs font-medium uppercase tracking-wide text-clay",
									children: "Hoy"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "font-display text-3xl text-ink",
									children: ["$9.99 ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-lg text-muted line-through",
										children: "$47"
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-sm text-muted",
									children: "Ahorras $37. El precio sube mañana."
								})
							]
						})]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
					className: "bg-forest text-surface",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mx-auto grid max-w-5xl gap-8 px-5 py-14 sm:grid-cols-3",
						children: [
							["Dejas de adivinar", "El plan te dice qué comer los 21 días. No hay “¿y ahora qué ceno?”."],
							["Cocinas con lo de casa", "Huevo, pollo, palta, verdura. Nada raro ni caro."],
							["No pasas hambre", "Comes rico y sacias. El objetivo es sostenerlo, no sufrir 21 días."]
						].map(([title, body]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "font-display text-2xl",
							children: title
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 text-surface/80",
							children: body
						})] }, title))
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					id: "incluye",
					className: "mx-auto max-w-5xl px-5 py-16",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm font-semibold uppercase tracking-widest text-clay",
							children: "El pack"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "mt-2 max-w-2xl font-display text-4xl text-ink",
							children: "Todo lo que recibes hoy, por menos de un almuerzo."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-8 grid gap-4 md:grid-cols-2",
							children: [INCLUDES.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
								className: "rounded-3xl bg-surface p-5 ring-1 ring-line",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "mb-3 flex size-10 items-center justify-center rounded-full bg-bg-deep text-forest",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "size-5" })
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
										className: "text-lg font-semibold",
										children: item.title
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-1 text-muted",
										children: item.detail
									})
								]
							}, item.title)), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
								className: "overflow-hidden rounded-3xl bg-ink text-surface md:col-span-2 md:grid md:grid-cols-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
									src: "/food/plate.jpg",
									alt: "Pollo a la plancha con palta y ensalada",
									className: "h-56 w-full object-cover md:h-full"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "p-6",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-sm text-gold",
											children: "Ejemplo real del tipo de plato"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
											className: "mt-2 font-display text-3xl",
											children: "Pollo, palta y ensalada en 15 minutos"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "mt-3 text-surface/75",
											children: "Comida de verdad. No polvos, no batidos obligatorios, no menú triste de lechuga."
										})
									]
								})]
							})]
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
					className: "bg-bg-deep",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mx-auto grid max-w-5xl items-center gap-8 px-5 py-16 lg:grid-cols-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
							src: "/food/ingredients.jpg",
							alt: "Ingredientes simples de cocina",
							className: "aspect-video w-full rounded-3xl object-cover"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "font-display text-4xl",
							children: "El plan de 21 días quita la decisión."
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
							className: "mt-6 space-y-4",
							children: [
								["Días 1–7", "Desinflamación. Menos hinchazón, más energía, antojos a la baja."],
								["Días 8–14", "Ritmo. Ya sabes qué cocinar y el cuerpo responde."],
								["Días 15–21", "Resultado visible y el hábito para no volver atrás."]
							].map(([k, v], i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
								className: "flex gap-4",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "flex size-8 shrink-0 items-center justify-center rounded-full bg-forest text-sm font-semibold text-surface",
									children: i + 1
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "font-semibold",
									children: [k, ". "]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-muted",
									children: v
								})] })]
							}, k))
						})] })]
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "mx-auto max-w-5xl px-5 py-16",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "flex items-end justify-between gap-4",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "font-display text-4xl",
								children: "Lo que dicen quienes ya lo hicieron"
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 max-w-2xl text-sm text-muted",
							children: "Testimonios reportados por alumnas. Los resultados varían según constancia, sueño y punto de partida. No es un resultado garantizado."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-3",
							children: QUOTES.map((q) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("figure", {
								className: "rounded-3xl bg-surface p-5 ring-1 ring-line",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "font-display text-2xl text-forest",
										children: q.result
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("blockquote", {
										className: "mt-3 text-ink",
										children: [
											"“",
											q.text,
											"”"
										]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("figcaption", {
										className: "mt-4 text-sm font-medium text-muted",
										children: q.name
									})
								]
							}, q.name))
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "mx-auto grid max-w-5xl gap-8 px-5 pb-16 lg:grid-cols-[0.8fr_1.2fr]",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: "/food/juice.jpg",
						alt: "Jugo verde de apio y pepino",
						className: "aspect-[3/4] w-full rounded-3xl object-cover"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm font-semibold uppercase tracking-widest text-clay",
							children: "Bonos de hoy"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "mt-2 font-display text-4xl",
							children: "5 extras que valen $155. Hoy van incluidos."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
							className: "mt-6 divide-y divide-line rounded-3xl bg-surface ring-1 ring-line",
							children: BONUSES.map((b) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
								className: "flex items-center justify-between gap-4 px-5 py-4",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "flex items-center gap-3 font-medium",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sparkles, { className: "size-4 text-clay" }), b.name]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "text-sm text-muted",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("s", { children: b.value }),
										" ",
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "font-semibold text-forest",
											children: "GRATIS"
										})
									]
								})]
							}, b.name))
						})
					] })]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
					id: "precio",
					className: "bg-forest-deep text-surface",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mx-auto max-w-xl px-5 py-16 text-center",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-sm uppercase tracking-widest text-gold",
								children: "Pago único"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "mt-2 font-display text-4xl",
								children: "Llévalo hoy por $9.99"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 text-surface/70",
								children: "Precio normal $47. Acceso de por vida al recetario y al plan."
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-8 rounded-3xl bg-surface p-6 text-left text-ink",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
										className: "space-y-3",
										children: [
											"120 recetas",
											"Plan de 21 días",
											"Ejercicios en casa",
											"Hábitos diarios",
											"5 bonos incluidos",
											"Grupo de WhatsApp",
											"Garantía de 7 días"
										].map((row) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
											className: "flex items-center gap-2",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "size-4 text-forest" }), row]
										}, row))
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-6 font-display text-5xl",
										children: "$9.99"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-muted",
										children: "en vez de $47 · ahorras $37"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
										href: CHECKOUT,
										className: "mt-6 inline-flex min-h-14 w-full items-center justify-center rounded-full bg-clay text-lg font-semibold text-surface",
										children: "Sí, quiero empezar hoy"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "mt-3 flex items-center justify-center gap-2 text-sm text-muted",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Lock, { className: "size-4" }), " Pago seguro en Hotmart"]
									})
								]
							})
						]
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "mx-auto max-w-3xl px-5 py-16",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex gap-4 rounded-3xl bg-surface p-6 ring-1 ring-line",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldCheck, { className: "size-8 shrink-0 text-forest" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "font-display text-2xl",
							children: "Garantía de 7 días"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 text-muted",
							children: "Si sientes que no es para ti, escribes dentro de los primeros 7 días y te devuelven el 100%. Sin preguntas y sin trámites."
						})] })]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-10",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "font-display text-3xl",
							children: "Preguntas frecuentes"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-4 divide-y divide-line",
							children: FAQS.map((f, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								className: "flex w-full items-center justify-between gap-4 py-4 text-left text-lg font-medium",
								onClick: () => setOpen(open === i ? -1 : i),
								"aria-expanded": open === i,
								children: [f.q, /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronDown, { className: `size-5 shrink-0 transition ${open === i ? "rotate-180" : ""}` })]
							}), open === i && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "pb-4 text-muted",
								children: f.a
							})] }, f.q))
						})]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "mx-auto max-w-3xl px-5 pb-20 text-center",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(UtensilsCrossed, { className: "mx-auto size-8 text-forest" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "mt-4 font-display text-4xl",
							children: "Cada día que lo postergas, sigues hinchada y sin un plan."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mx-auto mt-3 max-w-lg text-muted",
							children: "Por $9.99 tienes estructura para los próximos 21 días. Si no te sirve, lo recuperas."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-6 flex justify-center",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Cta, { children: "Quiero bajar de peso hoy" })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-4 inline-flex items-center gap-2 text-sm text-muted",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Clock, { className: "size-4" }), " El precio de $9.99 es solo por hoy."]
						})
					]
				})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("footer", {
				className: "border-t border-line px-5 py-8 text-center text-xs text-muted",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Resultados individuales. Este material es educativo y no reemplaza consejo médico." }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2",
					children: "Pago procesado por Hotmart. Acceso digital inmediato."
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "fixed inset-x-0 bottom-0 z-20 border-t border-line bg-surface/95 p-3 backdrop-blur sm:hidden",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
					href: CHECKOUT,
					className: "flex min-h-12 w-full items-center justify-center rounded-full bg-clay text-base font-semibold text-surface",
					children: "Empezar hoy · $9.99"
				})
			})
		]
	});
}
//#endregion
export { Home as component };
