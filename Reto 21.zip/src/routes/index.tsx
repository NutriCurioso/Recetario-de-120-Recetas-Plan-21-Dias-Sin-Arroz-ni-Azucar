import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import {
  Check,
  ChevronDown,
  Clock,
  Leaf,
  Lock,
  ShieldCheck,
  Sparkles,
  Star,
} from "lucide-react";

export const Route = createFileRoute("/")({ component: Home });

const CHECKOUT = "https://go.hotmart.com/P107932025G?ap=3ce2";

const INCLUDES = [
  { title: "120 recetas para desinflamar", detail: "Desayuno, almuerzo, cena y snack. De 5 a 20 minutos, con lo que ya compras en el mercado." },
  { title: "Plan de 21 días, día por día", detail: "Sin arroz y sin azúcar. Abres el día y ya sabes qué cocinar. Se acabó decidir cansada." },
  { title: "Ejercicios en casa, 15–20 min", detail: "Sin gym, sin máquinas y sin experiencia. Un bloque corto que cabe después del trabajo." },
  { title: "Hábitos que sostienen el cambio", detail: "Agua, sueño y antojos. Para que el día 22 no vuelvas al punto de partida." },
  { title: "Grupo de mujeres en WhatsApp", detail: "Recetas nuevas cada semana y compañía de quien está en el mismo proceso." },
];

const BONUSES = [
  { name: "Grupo VIP de WhatsApp", value: "$47" },
  { name: "Recetario de jugos verdes", value: "$37" },
  { name: "Plan de hábitos de 21 días", value: "$27" },
  { name: "Lista de compras para imprimir", value: "$17" },
  { name: "Guía de ejercicios 15–20 min", value: "$27" },
];

const REVIEWS = [
  { name: "Evelyn S.", meta: "Grupo Reto Total Fit", result: "−9 libras", text: "Este es mi peso con el que inicié. Y este es mi peso del día de hoy: en total he perdido 9 libras." },
  { name: "Amarilis E.", meta: "Grupo Reto Total Fit", result: "−6", text: "Hoy me pesé y sé que soy muy lenta bajando, pero gracias a Dios tengo 6 menos." },
  { name: "Mamá de tres", meta: "Grupo Reto Total Fit", result: "238 → 233", text: "Me pesé. Mi peso era 238, tengo 233." },
  { name: "Cristina T.", meta: "Grupo Reto Total Fit", result: "−3 libras", text: "Buen día. Yo me pesé el sábado y tenía 3 libras menos." },
  { name: "Del grupo", meta: "Grupo Reto Total Fit", result: "Se nota", text: "Me pesé ayer domingo y tengo 3 libras menos. Ya mi cambio se está notando." },
  { name: "Rosi", meta: "Grupo Reto Total Fit", result: "Constancia", text: "Más motivada que nunca." },
];

const FAQS = [
  { q: "¿Cómo lo recibo?", a: "Pagas una sola vez en Hotmart. En menos de un minuto el acceso llega a tu correo. No hay caja ni envío." },
  { q: "¿Sirve si trabajo todo el día?", a: "Está pensado para eso. Las recetas son cortas y el plan ya dice qué comer. No improvisas a las 8 de la noche." },
  { q: "¿Necesito gym?", a: "No. Los ejercicios son en casa, 15 a 20 minutos, sin equipo." },
  { q: "¿Y si no es para mí?", a: "Tienes 7 días. Escribes y te devuelven el 100%. El riesgo de probarlo es cero." },
  { q: "¿Puedo usarlo si lacto o tengo una condición?", a: "Es alimentación, no un tratamiento. Si estás embarazada, lactando o con una condición diagnosticada, consúltalo con tu médico antes." },
];

function parts(diff: number) {
  const h = Math.floor(diff / 3_600_000);
  const m = Math.floor((diff % 3_600_000) / 60_000);
  const s = Math.floor((diff % 60_000) / 1000);
  return { h: String(h).padStart(2, "0"), m: String(m).padStart(2, "0"), s: String(s).padStart(2, "0") };
}

function msUntilMidnight() {
  const now = new Date();
  const end = new Date(now);
  end.setHours(23, 59, 59, 0);
  let diff = end.getTime() - now.getTime();
  if (diff < 1500) {
    end.setDate(end.getDate() + 1);
    diff = end.getTime() - now.getTime();
  }
  return diff;
}

function useDeadline() {
  const [left, setLeft] = useState<ReturnType<typeof parts> | null>(null);
  useEffect(() => {
    const tick = () => setLeft(parts(msUntilMidnight()));
    tick();
    const id = setInterval(tick, 1000);
    return () => clearInterval(id);
  }, []);
  return left;
}

function Stars() {
  return (
    <span className="flex gap-0.5 text-clay" aria-label="5 de 5">
      {Array.from({ length: 5 }).map((_, i) => (
        <Star key={i} className="size-4 fill-current" />
      ))}
    </span>
  );
}

function Cta({ children }: { children: string }) {
  return (
    <a
      href={CHECKOUT}
      className="inline-flex min-h-14 w-full items-center justify-center rounded-full bg-clay px-6 text-lg font-semibold text-surface shadow-[0_14px_30px_-14px_rgba(196,92,38,0.9)] transition hover:bg-clay-deep sm:w-auto"
    >
      {children}
    </a>
  );
}

function Home() {
  const t = useDeadline();
  const [open, setOpen] = useState(0);

  return (
    <div className="pb-28 sm:pb-0">
      <div className="bg-forest text-surface">
        <div className="mx-auto flex max-w-5xl flex-wrap items-center justify-center gap-x-4 gap-y-1 px-4 py-2 text-sm">
          <span className="font-medium">Hoy $9.99 en vez de $47 · pago único</span>
          <span className="tabular-nums text-gold">{t ? `el precio cambia en ${t.h}:${t.m}:${t.s}` : "solo por hoy"}</span>
        </div>
      </div>

      <header className="mx-auto flex max-w-5xl items-center justify-between px-5 py-5">
        <p className="font-display text-xl text-forest">Plan 21 Días</p>
        <a href={CHECKOUT} className="hidden min-h-11 items-center rounded-full bg-forest px-5 text-sm font-semibold text-surface sm:inline-flex">
          Quiero empezar
        </a>
      </header>

      <main>
        <section className="mx-auto grid max-w-5xl items-center gap-12 px-5 pb-16 pt-2 lg:grid-cols-[1.05fr_0.95fr]">
          <div>
            <p className="mb-4 inline-flex items-center gap-2 rounded-full bg-bg-deep px-3 py-1 text-sm font-medium text-forest">
              <Leaf className="size-4" /> Hecho para mujeres de 24 a 55
            </p>
            <h1 className="font-display text-4xl leading-[1.05] tracking-tight text-ink sm:text-6xl">
              El vientre más plano empieza por dejar de improvisar la cena.
            </h1>
            <p className="mt-5 max-w-xl text-lg text-muted">
              120 recetas y un plan de 21 días, sin arroz y sin azúcar. Comes rico, en casa, en minutos. No es otra dieta para sufrir: es el menú que te faltaba.
            </p>
            <div className="mt-6 flex flex-wrap gap-3 text-sm">
              <span className="rounded-full bg-surface px-3 py-2 ring-1 ring-line">+2.300 mujeres en el plan</span>
              <span className="rounded-full bg-surface px-3 py-2 ring-1 ring-line">Recetas de 5 a 20 min</span>
              <span className="rounded-full bg-surface px-3 py-2 ring-1 ring-line">Garantía de 7 días</span>
            </div>
            <div className="mt-8 flex flex-col gap-3 sm:flex-row sm:items-center">
              <Cta>Quiero mi plan · $9.99</Cta>
              <p className="text-sm text-muted">Acceso al correo al instante. Si no te sirve, te devuelven todo.</p>
            </div>
          </div>
          <div className="stage">
            <div className="card-3d relative">
              <img src="/food/bowl.jpg" alt="Bowl de yogur, frutas y menta" className="aspect-[4/3] w-full rounded-3xl object-cover" />
              <div className="float-card absolute -bottom-6 left-4 right-4 rounded-2xl bg-surface p-4 ring-1 ring-line sm:left-auto sm:w-72">
                <p className="text-xs font-semibold uppercase tracking-wide text-clay">Precio de hoy</p>
                <p className="font-display text-4xl text-ink">$9.99 <span className="text-lg text-muted line-through">$47</span></p>
                <p className="text-sm text-muted">Ahorras $37. Mañana vuelve el precio normal.</p>
              </div>
            </div>
          </div>
        </section>

        <section className="bg-forest text-surface">
          <div className="mx-auto grid max-w-5xl gap-8 px-5 py-14 sm:grid-cols-3">
            {[
              ["Te reconoces aquí", "Pruebas el lunes, el miércoles ya no hay plan y el fin de semana vuelves a hincharte."],
              ["No es falta de fuerza", "Es falta de un menú claro. Cuando decides con hambre, gana el antojo."],
              ["21 días con estructura", "Qué comer, cuándo y con qué. Tú solo cocinas y sigues."],
            ].map(([title, body]) => (
              <div key={title}>
                <h2 className="font-display text-2xl">{title}</h2>
                <p className="mt-2 text-surface/80">{body}</p>
              </div>
            ))}
          </div>
        </section>

        <section className="mx-auto max-w-5xl px-5 py-16">
          <p className="text-sm font-semibold uppercase tracking-widest text-clay">Dentro del pack</p>
          <h2 className="mt-2 max-w-2xl font-display text-4xl">Todo lo que una mujer ocupada necesita para no abandonar a mitad de semana.</h2>
          <div className="mt-8 grid gap-4 md:grid-cols-2">
            {INCLUDES.map((item) => (
              <article key={item.title} className="rounded-3xl bg-surface p-5 ring-1 ring-line">
                <div className="mb-3 flex size-10 items-center justify-center rounded-full bg-bg-deep text-forest">
                  <Check className="size-5" />
                </div>
                <h3 className="text-lg font-semibold">{item.title}</h3>
                <p className="mt-1 text-muted">{item.detail}</p>
              </article>
            ))}
          </div>
          <article className="mt-4 overflow-hidden rounded-3xl bg-ink text-surface md:grid md:grid-cols-2">
            <img src="/food/plate.jpg" alt="Pollo, palta y ensalada" className="h-56 w-full object-cover md:h-full" />
            <div className="p-6">
              <p className="text-sm text-gold">Así se ve una comida del plan</p>
              <h3 className="mt-2 font-display text-3xl">Pollo, palta y ensalada. Quince minutos.</h3>
              <p className="mt-3 text-surface/75">Comida de mujer adulta, no un menú de castigo. Sacias, cocinas rápido y al día siguiente la ropa se siente distinta.</p>
            </div>
          </article>
        </section>

        <section className="bg-bg-deep">
          <div className="mx-auto grid max-w-5xl items-center gap-8 px-5 py-16 lg:grid-cols-2">
            <div className="stage">
              <img src="/food/ingredients.jpg" alt="Ingredientes simples" className="card-3d aspect-video w-full rounded-3xl object-cover" />
            </div>
            <div>
              <h2 className="font-display text-4xl">Tres semanas. Un solo trabajo: seguir el día.</h2>
              <ol className="mt-6 space-y-4">
                {[
                  ["Días 1–7", "Menos hinchazón. El cuerpo suelta líquido y los antojos bajan."],
                  ["Días 8–14", "Ya no piensas qué cocinar. El ritmo se vuelve automático."],
                  ["Días 15–21", "Ves el cambio en la báscula y en cómo te queda la ropa."],
                ].map(([k, v], i) => (
                  <li key={k} className="flex gap-4">
                    <span className="flex size-8 shrink-0 items-center justify-center rounded-full bg-forest text-sm font-semibold text-surface">{i + 1}</span>
                    <p><span className="font-semibold">{k}. </span><span className="text-muted">{v}</span></p>
                  </li>
                ))}
              </ol>
              <p className="mt-4 text-sm text-muted">Los kilos dependen de tu punto de partida, sueño y constancia. No es un resultado garantizado.</p>
            </div>
          </div>
        </section>

        <section className="mx-auto max-w-5xl px-5 py-16">
          <div className="flex flex-wrap items-end justify-between gap-3">
            <h2 className="font-display text-4xl">Reseñas de mujeres del grupo</h2>
            <p className="text-sm text-muted">Mensajes reales del Reto Total Fit</p>
          </div>
          <div className="mt-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {REVIEWS.map((q) => (
              <figure key={q.name + q.result} className="flex flex-col rounded-3xl bg-surface p-5 ring-1 ring-line">
                <Stars />
                <p className="mt-3 font-display text-2xl text-forest">{q.result}</p>
                <blockquote className="mt-2 flex-1 text-ink">“{q.text}”</blockquote>
                <figcaption className="mt-4 text-sm">
                  <span className="font-semibold">{q.name}</span>
                  <span className="mt-0.5 block text-muted">{q.meta}</span>
                </figcaption>
              </figure>
            ))}
          </div>
        </section>

        <section className="mx-auto grid max-w-5xl items-center gap-8 px-5 pb-16 lg:grid-cols-[0.75fr_1.25fr]">
          <div className="stage">
            <img src="/food/juice.jpg" alt="Jugo verde" className="card-3d aspect-[3/4] w-full rounded-3xl object-cover" />
          </div>
          <div>
            <p className="text-sm font-semibold uppercase tracking-widest text-clay">Solo con la compra de hoy</p>
            <h2 className="mt-2 font-display text-4xl">Cinco extras que por separado valen $155. Hoy van dentro.</h2>
            <ul className="mt-6 divide-y divide-line rounded-3xl bg-surface ring-1 ring-line">
              {BONUSES.map((b) => (
                <li key={b.name} className="flex items-center justify-between gap-4 px-5 py-4">
                  <span className="flex items-center gap-3 font-medium"><Sparkles className="size-4 text-clay" />{b.name}</span>
                  <span className="text-sm text-muted"><s>{b.value}</s> <span className="font-semibold text-forest">Incluido</span></span>
                </li>
              ))}
            </ul>
          </div>
        </section>

        <section className="bg-forest-deep text-surface">
          <div className="mx-auto max-w-xl px-5 py-16 text-center">
            <p className="text-sm uppercase tracking-widest text-gold">Menos que un delivery</p>
            <h2 className="mt-2 font-display text-4xl">21 días de orden por $9.99</h2>
            <p className="mt-2 text-surface/70">Un pago. Acceso de por vida. Sin mensualidad.</p>
            <div className="stage mt-8">
              <div className="card-3d rounded-3xl bg-surface p-6 text-left text-ink">
                <ul className="space-y-3">
                  {["120 recetas", "Plan día por día", "Ejercicios en casa", "Hábitos", "5 bonos", "Grupo de WhatsApp", "7 días para arrepentirte"].map((row) => (
                    <li key={row} className="flex items-center gap-2"><Check className="size-4 text-forest" />{row}</li>
                  ))}
                </ul>
                <p className="mt-6 font-display text-5xl">$9.99</p>
                <p className="text-muted">antes $47</p>
                <a href={CHECKOUT} className="mt-6 inline-flex min-h-14 w-full items-center justify-center rounded-full bg-clay text-lg font-semibold text-surface">
                  Sí, lo quiero para mí
                </a>
                <p className="mt-3 flex items-center justify-center gap-2 text-sm text-muted"><Lock className="size-4" /> Pago seguro en Hotmart</p>
              </div>
            </div>
          </div>
        </section>

        <section className="mx-auto max-w-3xl px-5 py-16">
          <div className="flex gap-4 rounded-3xl bg-surface p-6 ring-1 ring-line">
            <ShieldCheck className="size-8 shrink-0 text-forest" />
            <div>
              <h2 className="font-display text-2xl">Si no te convence, no te queda.</h2>
              <p className="mt-2 text-muted">Siete días para abrirlo, ver las recetas y decidir. Si no es para ti, escriben y devuelven el 100%. Sin preguntas.</p>
            </div>
          </div>
          <h2 className="mt-10 font-display text-3xl">Antes de decidir</h2>
          <div className="mt-4 divide-y divide-line">
            {FAQS.map((f, i) => (
              <div key={f.q}>
                <button type="button" className="flex w-full items-center justify-between gap-4 py-4 text-left text-lg font-medium" onClick={() => setOpen(open === i ? -1 : i)} aria-expanded={open === i}>
                  {f.q}
                  <ChevronDown className={`size-5 shrink-0 transition ${open === i ? "rotate-180" : ""}`} />
                </button>
                {open === i && <p className="pb-4 text-muted">{f.a}</p>}
              </div>
            ))}
          </div>
        </section>

        <section className="mx-auto max-w-3xl px-5 pb-20 text-center">
          <h2 className="font-display text-4xl">Esta noche puedes volver a preguntarte qué cenar. O puedes tenerlo resuelto.</h2>
          <p className="mx-auto mt-3 max-w-lg text-muted">$9.99. Un correo. 21 días con estructura. Y siete días para pedir el reembolso si no te late.</p>
          <div className="mt-6 flex justify-center"><Cta>Empezar mis 21 días</Cta></div>
          <p className="mt-4 inline-flex items-center gap-2 text-sm text-muted"><Clock className="size-4" /> El precio de $9.99 cierra esta medianoche.</p>
        </section>
      </main>

      <footer className="border-t border-line px-5 py-8 text-center text-xs text-muted">
        <p>Resultados individuales. Material educativo: no reemplaza consejo médico.</p>
        <p className="mt-2">Pago procesado por Hotmart. Acceso digital inmediato.</p>
      </footer>

      <div className="fixed inset-x-0 bottom-0 z-20 border-t border-line bg-surface/95 p-3 backdrop-blur sm:hidden">
        <a href={CHECKOUT} className="flex min-h-12 w-full items-center justify-center rounded-full bg-clay text-base font-semibold text-surface">
          Empezar hoy · $9.99
        </a>
      </div>
    </div>
  );
}
